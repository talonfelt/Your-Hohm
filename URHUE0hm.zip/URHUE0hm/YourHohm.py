# -*- coding: utf-8 -*-
# Pythonista 3 — Toroidal Wave-Function COMPLETE WORKING VERSION
# Everything integrated - no manual editing needed

import ui, io, time, math, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.mplot3d import Axes3D
import os

# ---------- quality settings ----------
N_INTERACT = 32
N_IDLE     = 64
IDLE_DELAY = 0.28
DPI_SMALL, DPI_MED, DPI_BIG = 100, 110, 120

# ---------- color presets ----------
COLOR_PRESETS = {
    'Full Spectrum': {'r': 1.0, 'g': 1.0, 'b': 1.0},
    'Cool Tones': {'r': 0.0, 'g': 0.7, 'b': 1.0},
    'Warm Tones': {'r': 1.0, 'g': 0.8, 'b': 0.0},
    'Cyan/Blue': {'r': 0.0, 'g': 1.0, 'b': 1.0},
    'Magenta/Red': {'r': 1.0, 'g': 0.0, 'b': 0.7},
    'Green Only': {'r': 0.0, 'g': 1.0, 'b': 0.0},
    'Blue Only': {'r': 0.0, 'g': 0.0, 'b': 1.0},
    'Red Only': {'r': 1.0, 'g': 0.0, 'b': 0.0},
}

# ---------- compute surface ----------  
def compute_surface(params, t, base_N, fold_offset=0):
    """Compute toroidal surface with power refraction"""
    try:
        i_fold = int(round(params['i'])) + fold_offset
        tau    = float(params['tau'])
        R      = float(params['R'])
        r0     = float(params['r0'])
        mid_r  = float(params['mid_r'])
        mod_k  = float(params['mod_k'])
        z_spiral = float(params.get('z_spiral', 0.0))

        N = int(base_N * (1 + abs(i_fold) / 20.0))
        N = max(32, min(N, 512))

        phi   = (1 + np.sqrt(5.0)) / 2.0
        iota  = phi**2
        omega = np.pi / phi
        theta = 2.0 * np.pi / phi
        
        # Power refraction
        if abs(i_fold) > 0:
            P = np.clip(phi**abs(i_fold), 1e-10, 1e10)
            P_prev = np.clip(phi**(abs(i_fold) - 1), 1e-10, 1e10) if abs(i_fold) > 1 else 1.0
            
            D = abs(P - phi)
            D_prev = abs(P_prev - phi)
            
            Z = len(str(int(D))) if D >= 1 else 0
            Z_prev = len(str(int(D_prev))) if D_prev >= 1 else 0
            
            Q = D / (10.0**Z) if Z > 0 else D
            Q_prev = D_prev / (10.0**Z_prev) if Z_prev > 0 else D_prev
            
            V = phi - Q_prev
            
            if V <= phi:
                lambda_val = (Q / phi) * V
            else:
                lambda_val = Q / phi
            
            Lambda = max(V - lambda_val, 0.001)
            A = np.clip(P / Lambda, 0.01, 1e8)
        else:
            Lambda = 1.0
            A = 1.0
        
        s = np.clip(phi**abs(i_fold), 1e-10, 1e10)
        M = np.cos(2.0 * np.pi * omega / phi**min(abs(i_fold), 10))
        F = 1.0 / (np.pi + 2.0/3.0)

        theta_s = np.linspace(0, 2*np.pi, N)
        phi_s   = np.linspace(0, 2*np.pi, N)
        Theta_s, Phi_s = np.meshgrid(theta_s, phi_s)

        phase = (tau * t) + theta + Theta_s + (omega * s)
        psi = A * phi**s * np.cos(phase) * np.sin(Phi_s / iota) * M * F
        psi = np.nan_to_num(psi, nan=0.0, posinf=0.0, neginf=0.0)
        psi = psi / (np.max(np.abs(psi)) + 1e-10)

        r = abs(r0) + abs(mid_r) * abs(mod_k) * np.abs(psi)
        
        X = (R + r * np.cos(Theta_s)) * np.cos(Phi_s)
        Y = (R + r * np.cos(Theta_s)) * np.sin(Phi_s)
        Z = r * np.sin(Theta_s) + z_spiral * Phi_s / (2 * np.pi)

        X = np.nan_to_num(X)
        Y = np.nan_to_num(Y)
        Z = np.nan_to_num(Z)

        return X, Y, Z, Theta_s, Phi_s
    except Exception as e:
        print(f"compute_surface error: {e}")
        return np.array([0]), np.array([0]), np.array([0]), np.array([0]), np.array([0])

def fig_to_ui_image(fig, dpi=130):
    try:
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=int(dpi), bbox_inches='tight',
                    pad_inches=0.02, facecolor=fig.get_facecolor())
        img = ui.Image.from_data(buf.getvalue())
        buf.close()
        return img
    except:
        return None

def clamp(x, lo, hi): return max(lo, min(hi, x))
def norm_from_value(v, mn, mx): return (v - mn) / (mx - mn) if mx > mn else 0.5
def value_from_norm(u, mn, mx): return mn + u * (mx - mn)

# ---------- plot view with FIXED gestures ----------
class PlotView(ui.View):
    def __init__(self, owner):
        super().__init__()
        self.bg_color = 'black'
        self.owner = owner
        self.multiple_touch_enabled = True
        self.iv = ui.ImageView()
        self.iv.flex = 'WH'
        self.iv.bg_color = 'black'
        self.add_subview(self.iv)
        self.azim = 40.0
        self.elev = 28.0
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._touches = {}
        self._prev_touches = {}

    def layout(self): self.iv.frame = self.bounds
    
    def reset_view(self):
        self.azim = 40.0; self.elev = 28.0; self.zoom = 1.0
        self.pan_x = 0.0; self.pan_y = 0.0
        self.owner._mark_interaction(); self.owner._redraw()

    def touch_began(self, touch):
        self._touches[touch.touch_id] = touch.location
        self._prev_touches[touch.touch_id] = touch.location
        self.owner._mark_interaction()

    def touch_moved(self, touch):
        current_pos = touch.location
        prev_pos = self._prev_touches.get(touch.touch_id, current_pos)
        self._touches[touch.touch_id] = current_pos
        
        if len(self._touches) == 1:
            # Single touch: rotate
            dx = current_pos[0] - prev_pos[0]
            dy = current_pos[1] - prev_pos[1]
            w = max(1.0, self.width); h = max(1.0, self.height)
            
            self.azim -= (dx / w) * 180.0
            self.elev += (dy / h) * 120.0
            self.elev = clamp(self.elev, -89.0, 89.0)
            
        elif len(self._touches) == 2:
            # Two touches: pinch zoom
            touch_ids = list(self._touches.keys())
            p1 = self._touches[touch_ids[0]]
            p2 = self._touches[touch_ids[1]]
            p1_prev = self._prev_touches.get(touch_ids[0], p1)
            p2_prev = self._prev_touches.get(touch_ids[1], p2)
            
            def dist(a, b): return math.hypot(a[0]-b[0], a[1]-b[1])
            current_dist = dist(p1, p2)
            prev_dist = dist(p1_prev, p2_prev)
            
            if prev_dist > 0:
                zoom_factor = current_dist / prev_dist
                self.zoom = clamp(self.zoom * zoom_factor, 0.1, 10.0)
            
        elif len(self._touches) == 3:
            # Three touches: pan camera
            touch_ids = list(self._touches.keys())
            current_center = np.mean([self._touches[tid] for tid in touch_ids], axis=0)
            prev_center = np.mean([self._prev_touches.get(tid, self._touches[tid]) for tid in touch_ids], axis=0)
            
            dx = current_center[0] - prev_center[0]
            dy = current_center[1] - prev_center[1]
            w = max(1.0, self.width); h = max(1.0, self.height)
            
            self.pan_x += (dx / w) * 40.0
            self.pan_y -= (dy / h) * 40.0
    
        self._prev_touches[touch.touch_id] = current_pos
        self.owner._mark_interaction()
        self.owner._redraw()

    def touch_ended(self, touch):
        self._touches.pop(touch.touch_id, None)
        self._prev_touches.pop(touch.touch_id, None)
        self.owner._mark_interaction()

# ---------- control panel with COLLAPSIBLE CATEGORIES ----------
class ControlPanel(ui.View):
    def __init__(self, app):
        super().__init__(bg_color='#0B0B0B')
        self.app = app
        self.flex = 'WH'
        
        self.expanded = {
            'wave': True,
            'geometry': True, 
            'appearance': True,
            'system': False,
            'layers': True
        }
        
        self.scroll = ui.ScrollView()
        self.scroll.flex = 'WH'
        self.scroll.bg_color = '#0B0B0B'
        self.add_subview(self.scroll)
        
        self.w = {}
        self._build()

    def _label(self, text, key, small=False):
        lbl = ui.Label(text=text, font=('<s>', 12 if small else 14),
                       alignment=ui.ALIGN_LEFT,
                       text_color='#DADADA' if small else '#FFFFFF')
        self.scroll.add_subview(lbl)
        self.w[key] = lbl

    def _slider(self, val, action, key):
        s = ui.Slider(name=f'sld_{key}')
        s.min_value = 0.0; s.max_value = 1.0; s.value = float(val); s.action = action
        self.scroll.add_subview(s)
        self.w[f'sld_{key}'] = s

    def _button(self, title, action, key, color='#1F2A44', tint='white'):
        b = ui.Button(title=title, action=action)
        b.corner_radius = 8; b.bg_color = color; b.tint_color = tint
        self.scroll.add_subview(b)
        self.w[key] = b
        
    def _category_button(self, title, category_key):
        def toggle(sender):
            self.expanded[category_key] = not self.expanded[category_key]
            symbol = '▼' if self.expanded[category_key] else '▶'
            sender.title = f"{symbol} {title}"
            self.layout()
            
        symbol = '▼' if self.expanded[category_key] else '▶'
        self._button(f"{symbol} {title}", toggle, f'cat_{category_key}', '#2A3A4A')

    def _build(self):
        p = self.app
        
        # Top buttons
        self._button('Exit', p._exit, 'btn_exit', '#7A1F1F')
        self._button('Zoom –', p._zoom_out, 'btn_zm_out', '#1F2A44')
        self._button('Zoom +', p._zoom_in, 'btn_zm_in', '#28406E')
        self._button('Color Preset', p._show_color_presets, 'btn_preset', '#4A2E6E')
        self._button('▶ Play', p._toggle_animation, 'btn_play', '#2E6E4A')
        
        self._label(' ', 'spacer_top', small=True)

        def add_row(name, key, category, is_int=False, fmt='{:.3f}'):
            self._label(name, f'lbl_{key}')
            self.w[f'lbl_{key}'].category = category
            
            val = p.params[key]
            self._label(str(int(round(val))) if is_int else fmt.format(val),
                        f'val_{key}', small=True)
            self.w[f'val_{key}'].category = category
            
            u = norm_from_value(val, *p.hard[key])
            self._slider(u, p._on_param, key)
            self.w[f'sld_{key}'].category = category

        # WAVE PARAMETERS category
        self._category_button('Wave Parameters', 'wave')
        add_row('Fold i:', 'i', 'wave', is_int=True)
        add_row('Torque τ:', 'tau', 'wave')
        add_row('Modulation |ψ|:', 'mod_k', 'wave')
        
        # LAYERS category
        self._category_button('Multi-Layer', 'layers')  
        add_row('Number of Layers:', 'layers', 'layers', is_int=True)
        add_row('Layer Spread:', 'layer_spread', 'layers')
        
        # GEOMETRY category
        self._category_button('Geometry', 'geometry')
        add_row('Major Radius R:', 'R', 'geometry')
        add_row('Tube Radius r0:', 'r0', 'geometry')
        add_row('Tube Thickness:', 'mid_r', 'geometry')
        add_row('Vertical Spiral:', 'z_spiral', 'geometry')
        
        # APPEARANCE category
        self._category_button('Appearance', 'appearance')
        add_row('Master Alpha:', 'alpha', 'appearance')
        add_row('Red Channel:', 'r_opacity', 'appearance')
        add_row('Green Channel:', 'g_opacity', 'appearance')
        add_row('Blue Channel:', 'b_opacity', 'appearance')
        
        # SYSTEM category
        self._category_button('System', 'system')
        add_row('Base Grid N:', 'N', 'system', is_int=True)

        # Time slider
        self._label('─── Animation ───', 'lbl_anim_header')
        self._label('Time:', 'lbl_t')
        self._label('t = 0.00', 'val_t', small=True)
        self._slider(0.0, p._on_time, 't')

        # Action buttons
        self._button('⤾ Reset View', p._reset_view, 'btn_view', '#5C2E7E')
        self._button('↺ Reset Time', p._reset_time, 'btn_reset', '#1F4D7A')
        self._button('💾 Save State', p._save_state, 'btn_save', '#2E5C7E')
        self._button('📂 Load State', p._load_state, 'btn_load', '#4E7C5E')
        self._button('📍 Reset Pan', p._reset_pan, 'btn_pan_reset', '#7E5C2E')

    def layout(self):
        self.scroll.frame = self.bounds
        pad = 10; x = pad; y = pad; w = int(self.width - 2*pad); gap = 6
        
        def show_widget(key, frame):
            if key in self.w:
                self.w[key].hidden = False
                self.w[key].frame = frame
        
        def hide_widget(key):
            if key in self.w:
                self.w[key].hidden = True
        
        # Top button row
        btn_w = int((w - 4*gap) / 5)
        show_widget('btn_exit', (x, y, btn_w, 36))
        show_widget('btn_zm_out', (x + btn_w + gap, y, btn_w, 36))
        show_widget('btn_zm_in', (x + 2*(btn_w + gap), y, btn_w, 36))
        show_widget('btn_preset', (x + 3*(btn_w + gap), y, btn_w, 36))
        show_widget('btn_play', (x + 4*(btn_w + gap), y, btn_w, 36))
        y += 44
        
        show_widget('spacer_top', (x, y, w, 2)); y += 10

        def place_row(key):
            nonlocal y
            widget = self.w.get(f'lbl_{key}')
            if widget and hasattr(widget, 'category'):
                category = widget.category
                if not self.expanded.get(category, True):
                    for wkey in (f'lbl_{key}', f'val_{key}', f'sld_{key}'):
                        hide_widget(wkey)
                    return
            
            show_widget(f'lbl_{key}', (x, y, w, 22)); y += 24
            show_widget(f'val_{key}', (x, y, w, 18)); y += 20
            show_widget(f'sld_{key}', (x, y, w, 32)); y += 38
            
        def place_category(cat_key, param_keys):
            nonlocal y
            show_widget(f'cat_{cat_key}', (x, y, w, 36)); y += 40
            if self.expanded[cat_key]:
                for key in param_keys:
                    place_row(key)
            else:
                for key in param_keys:
                    for wkey in (f'lbl_{key}', f'val_{key}', f'sld_{key}'):
                        hide_widget(wkey)

        place_category('wave', ['i', 'tau', 'mod_k'])
        place_category('layers', ['layers', 'layer_spread'])
        place_category('geometry', ['R', 'r0', 'mid_r', 'z_spiral'])
        place_category('appearance', ['alpha', 'r_opacity', 'g_opacity', 'b_opacity'])
        place_category('system', ['N'])
        
        # Time section
        show_widget('lbl_anim_header', (x, y, w, 20)); y += 24
        show_widget('lbl_t', (x, y, w, 22)); y += 24
        show_widget('val_t', (x, y, w, 18)); y += 20
        show_widget('sld_t', (x, y, w, 32)); y += 38

        # Action buttons
        show_widget('btn_view', (x, y, w, 40)); y += 46
        show_widget('btn_reset', (x, y, w, 40)); y += 46
        show_widget('btn_save', (x, y, w, 40)); y += 46
        show_widget('btn_load', (x, y, w, 40)); y += 46
        show_widget('btn_pan_reset', (x, y, w, 40)); y += 46

        self.scroll.content_size = (self.width, max(self.height+1, y + pad))

# ---------- main app with ALL IMPROVEMENTS ----------
class ToroidApp(ui.View):
    def __init__(self):
        super().__init__()
        self.name = 'Toroidal Wave-Function COMPLETE'
        self.bg_color = 'black'
        self.flex = 'WH'
        self._ui_guard = False
        self._last_interaction = 0.0
        self._animating = False
        self._anim_timer = None

        self.hard = {
            'i': (-15.3, 15.3),
            'tau': (-6.6, 6.6),
            'R': (-162.0, 162.0),
            'r0': (-162.0, 162.0),
            'mid_r': (-162.0, 162.0),
            'mod_k': (-81.0, 81.0),
            'z_spiral': (-810.0, 810.0),
            'alpha': (0.0, 1.00),
            'r_opacity': (0.0, 1.0),
            'g_opacity': (0.0, 1.0),
            'b_opacity': (0.0, 1.0),
            'N': (32.0, 512.0),
            'layers': (1.0, 6.0),
            'layer_spread': (0.1, 3.0),
        }
        
        self.params = {
            'i': 3.0,
            'tau': 0.1,
            'R': 8.0,
            'r0': 2.0,
            'mid_r': 3.0,
            'mod_k': 1.5,
            'z_spiral': 0.0,
            'alpha': 0.75,
            'r_opacity': 1.0,
            'g_opacity': 1.0,
            'b_opacity': 1.0,
            'N': 128.0,
            'layers': 1.0,
            'layer_spread': 1.0,
        }

        self.t = 0.0
        self.t_max = 27.0

        self.img = PlotView(owner=self); self.add_subview(self.img)
        self.ctrl = ControlPanel(app=self); self.add_subview(self.ctrl)

        self.fig = plt.figure(figsize=(5.2, 5.2))
        self.fig.patch.set_facecolor('black')
        self.ax = self.fig.add_subplot(111, projection='3d')
        self.ax.set_facecolor('black')

        self._redraw()

    def _mark_interaction(self): self._last_interaction = time.time()
    def _is_interacting(self): return (time.time() - self._last_interaction) < IDLE_DELAY

    def _with_ui_guard(self, fn):
        if self._ui_guard: return
        self._ui_guard = True
        try:
            fn()
        finally:
            self._ui_guard = False

    def _toggle_animation(self, sender):
        if self._animating:
            self._stop_animation()
            sender.title = '▶ Play'
        else:
            self._start_animation()
            sender.title = '⏸ Pause'

    def _start_animation(self):
        self._animating = True
        self._animate_frame()

    def _stop_animation(self):
        self._animating = False
        if self._anim_timer:
            self._anim_timer = None

    def _animate_frame(self):
        if not self._animating:
            return
            
        self.t = (self.t + 0.05) % self.t_max
        time_norm = norm_from_value(self.t, 0.0, self.t_max)
        self._with_ui_guard(lambda: setattr(self.ctrl.w['sld_t'], 'value', time_norm))
        
        self._refresh_labels()
        self._redraw()
        
        self._anim_timer = ui.delay(self._animate_frame, 0.033)

    def _show_color_presets(self, sender):
        table = ui.TableView()
        table.name = 'Color Presets'
        table.data_source = ui.ListDataSource(list(COLOR_PRESETS.keys()))
        
        def select_preset(sender):
            preset_name = sender.items[sender.selected_row]
            preset = COLOR_PRESETS[preset_name]
            self.params['r_opacity'] = preset['r']
            self.params['g_opacity'] = preset['g']
            self.params['b_opacity'] = preset['b']
            
            for channel in ['r_opacity', 'g_opacity', 'b_opacity']:
                norm_val = norm_from_value(self.params[channel], *self.hard[channel])
                self._with_ui_guard(
                    lambda c=channel, v=norm_val: setattr(self.ctrl.w[f'sld_{c}'], 'value', v)
                )
            
            self._refresh_labels()
            self._redraw()
            table.close()
            
        table.data_source.action = select_preset
        table.present('sheet')

    def _on_param(self, sender):
        if not sender.name: return
        key = sender.name.replace('sld_', '')
        if key not in self.params: return
        
        mn, mx = self.hard[key]
        v = value_from_norm(sender.value, mn, mx)
        self.params[key] = float(int(round(v))) if key in ('i', 'N', 'layers') else v
        
        self._refresh_labels()
        self._mark_interaction()
        self._redraw()

    def _on_time(self, sender):
        self.t = value_from_norm(sender.value, 0.0, self.t_max)
        self._refresh_labels()
        self._mark_interaction()
        self._redraw()

    def _refresh_labels(self):
        for key in self.params:
            if f'val_{key}' in self.ctrl.w:
                val = self.params[key]
                fmt = '{:.3f}' if key not in ('i', 'N', 'layers') else '{}'
                self.ctrl.w[f'val_{key}'].text = fmt.format(
                    int(round(val)) if key in ('i', 'N', 'layers') else val
                )
        if 'val_t' in self.ctrl.w:
            self.ctrl.w['val_t'].text = f't = {self.t:.2f}'

    def _redraw(self):
        try:
            self.ax.clear()
            N = int(self.params['N']) if not self._is_interacting() else min(int(self.params['N']), N_INTERACT)
            
            num_layers = int(self.params['layers'])
            layer_spread = float(self.params['layer_spread'])
            
            colors = [
                (1.0, 0.0, 0.0), (1.0, 0.3, 0.0), (1.0, 0.65, 0.0), (1.0, 1.0, 0.0),
                (0.5, 1.0, 0.0), (0.0, 1.0, 0.0), (0.0, 1.0, 0.5), (0.0, 1.0, 1.0),
                (0.0, 0.5, 1.0), (0.0, 0.0, 1.0), (0.3, 0.0, 1.0), (0.5, 0.0, 1.0),
                (0.75, 0.0, 1.0), (1.0, 0.0, 1.0), (1.0, 0.0, 0.5), (1.0, 0.0, 0.0)
            ]
            cmap = LinearSegmentedColormap.from_list('smooth_cyclic_rainbow', colors, N=2048)

            for layer in range(num_layers):
                if num_layers == 1:
                    fold_offset = 0
                else:
                    fold_offset = (layer - (num_layers-1)/2) * layer_spread
                
                X, Y, Z, Theta_s, Phi_s = compute_surface(self.params, self.t, N, fold_offset)
                
                if X.shape[0] <= 1:
                    continue
                    
                i_shift = (self.params['i'] + fold_offset) / 120.0
                t_shift = self.t / self.t_max
                color_values = (Theta_s / (2 * np.pi) + t_shift + i_shift) % 1.0
                colors_array = cmap(color_values)
                
                r_contribution = colors_array[..., 0] * self.params['r_opacity']
                g_contribution = colors_array[..., 1] * self.params['g_opacity'] 
                b_contribution = colors_array[..., 2] * self.params['b_opacity']
                
                colors_array[..., 0] = r_contribution
                colors_array[..., 1] = g_contribution
                colors_array[..., 2] = b_contribution
                colors_array[..., 3] = np.clip((r_contribution + g_contribution + b_contribution), 0, 1) * self.params['alpha']

                N_actual = X.shape[0]
                stride = max(1, int(N_actual / 12))
                
                self.ax.plot_surface(X, Y, Z, facecolors=colors_array, 
                                   rstride=stride, cstride=stride, 
                                   shade=False, antialiased=True)

            zoom = self.img.zoom
            lim = (10.0 / zoom)
            
            self.ax.set_xlim(-lim + self.img.pan_x, lim + self.img.pan_x)
            self.ax.set_ylim(-lim + self.img.pan_y, lim + self.img.pan_y)
            self.ax.set_zlim(-lim, lim)
            
            self.ax.set_axis_off()
            self.ax.view_init(elev=self.img.elev, azim=self.img.azim)
            self.ax.dist = 8.0 / self.img.zoom
            
            dpi = DPI_MED if self._is_interacting() else DPI_BIG
            img = fig_to_ui_image(self.fig, dpi)
            if img:
                self.img.iv.image = img
        except Exception as e:
            print(f"Redraw error: {e}")

    def _zoom_in(self, sender):
        self.img.zoom = clamp(self.img.zoom / 1.3, 0.1, 10.0)
        self._mark_interaction()
        self._redraw()

    def _zoom_out(self, sender):
        self.img.zoom = clamp(self.img.zoom * 1.3, 0.1, 10.0)
        self._mark_interaction()
        self._redraw()

    def _reset_view(self, sender):
        self.img.reset_view()

    def _reset_time(self, sender):
        self.t = 0.0
        self._with_ui_guard(lambda: setattr(self.ctrl.w['sld_t'], 'value', 0.0))
        self._refresh_labels()
        self._mark_interaction()
        self._redraw()

    def _reset_pan(self, sender):
        self.img.pan_x = 0.0
        self.img.pan_y = 0.0
        self._mark_interaction()
        self._redraw()

    def get_states_path(self):
        docs = os.path.expanduser('~/Documents')
        return os.path.join(docs, 'toroidal_states.json')

    def load_states(self):
        path = self.get_states_path()
        if os.path.exists(path):
            with open(path, 'r') as f:
                return json.load(f)
        return {}

    def save_states(self, states):
        path = self.get_states_path()
        with open(path, 'w') as f:
            json.dump(states, f, indent=2)

    def _save_state(self, sender):
        def save_action(tf_sender):
            label = tf.text.strip()
            if not label:
                return
            state = {
                'params': self.params.copy(),
                'camera': {'azim': self.img.azim, 'elev': self.img.elev, 'zoom': self.img.zoom,
                          'pan_x': self.img.pan_x, 'pan_y': self.img.pan_y},
                't': self.t
            }
            states = self.load_states()
            states[label] = state
            self.save_states(states)
            print(f"State '{label}' saved")
            save_view.close()

        save_view = ui.View()
        save_view.name = 'Save State'
        save_view.bg_color = 'white'
        save_view.width = 300
        save_view.height = 150

        tf = ui.TextField(frame=(10, 40, 280, 32))
        tf.placeholder = 'Enter state label'
        save_view.add_subview(tf)

        btn = ui.Button(title='Save', frame=(10, 90, 280, 32))
        btn.action = lambda s: save_action(tf)
        save_view.add_subview(btn)

        save_view.present('sheet')

    def _load_state(self, sender):
        states = self.load_states()
        if not states:
            ui.alert('No saved states', 'There are no saved states to load.', 'OK')
            return

        table = ui.TableView()
        table.name = 'Load State'
        labels = list(states.keys())
        table.data_source = ui.ListDataSource(labels)
        
        def select_state(sender):
            label = labels[sender.selected_row]
            state = states[label]
            self.params.update(state['params'])
            cam = state['camera']
            self.img.azim = cam['azim']
            self.img.elev = cam['elev']
            self.img.zoom = cam['zoom']
            self.img.pan_x = cam.get('pan_x', 0.0)
            self.img.pan_y = cam.get('pan_y', 0.0)
            self.t = state['t']
            
            for key, val in self.params.items():
                if key in self.hard:
                    norm_val = norm_from_value(val, *self.hard[key])
                    self._with_ui_guard(
                        lambda k=key, v=norm_val: setattr(self.ctrl.w[f'sld_{k}'], 'value', v)
                    )
            
            time_norm = norm_from_value(self.t, 0.0, self.t_max)
            self._with_ui_guard(lambda: setattr(self.ctrl.w['sld_t'], 'value', time_norm))
            
            self._refresh_labels()
            self._mark_interaction()
            self._redraw()
            print(f"State '{label}' loaded")
            table.close()
            
        table.data_source.action = select_state
        table.present('sheet')

    def _exit(self, sender):
        self._stop_animation()
        self.close()
    def layout(self):
        w, h = self.bounds.size
        is_portrait = h > w
        ctrl_w = min(320, w * 0.4)
        if is_portrait:
            plot_h = h * 0.6
            self.img.frame = (0, 0, w, plot_h)
            self.ctrl.frame = (0, plot_h, w, h - plot_h)
        else:
            self.img.frame = (0, 0, w - ctrl_w, h)
            self.ctrl.frame = (w - ctrl_w, 0, ctrl_w, h)
        self.ctrl.layout()

if __name__ == '__main__':
    try:
        app = ToroidApp()
        app.present('fullscreen', hide_title_bar=True)
    except Exception as e:
        print(f"App error: {e}")
        import traceback
        traceback.print_exc()